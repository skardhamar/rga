.extend.rga.mcf <- function() {
	NULL;
}